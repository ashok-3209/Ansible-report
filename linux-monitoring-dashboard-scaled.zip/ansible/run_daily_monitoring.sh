#!/bin/bash
# Daily job to gather data and move to web server directory
ansible-playbook /opt/linux-monitoring-dashboard/ansible/gather_combined_info.yml

# Optional: move to /var/www/html/ or scp to remote web server
cp /tmp/all_servers_combined.json /var/www/html/all_servers_combined.json